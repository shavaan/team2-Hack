"""
Shared Azure OAuth2 authentication module
"""
import requests
import os
from typing import Optional


def get_access_token(tenant_id: str, client_id: str, client_secret: str, scope: str) -> Optional[str]:
    """
    Get an access token using OAuth2 client credentials flow
    
    Args:
        tenant_id: Azure AD tenant ID
        client_id: Azure AD application client ID
        client_secret: Azure AD application client secret
        scope: OAuth2 scope for the token
        
    Returns:
        Access token string if successful, None otherwise
    """
    token_url = f"https://login.microsoftonline.com/{tenant_id}/oauth2/v2.0/token"
    
    # Prepare form data for token request
    token_data = {
        "grant_type": "client_credentials",
        "client_id": client_id,
        "client_secret": client_secret,
        "scope": scope
    }
    
    try:
        response = requests.post(token_url, data=token_data)
        
        if response.status_code == 200:
            token_response = response.json()
            access_token = token_response.get('access_token')
            if access_token:
                print("Successfully obtained access token")
                return access_token
            else:
                print("No access token found in response")
                return None
        else:
            print(f"Failed to get access token. Status code: {response.status_code}")
            print(f"Response: {response.text}")
            return None
            
    except Exception as e:
        print(f"Error getting access token: {str(e)}")
        return None

