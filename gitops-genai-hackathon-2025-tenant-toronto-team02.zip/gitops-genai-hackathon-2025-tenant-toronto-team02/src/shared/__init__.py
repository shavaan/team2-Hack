"""
Shared utilities for the Azure AI services project
"""

from .auth import get_access_token

__all__ = ['get_access_token']
