"""
Database Service for Law Changes
Handles database operations for storing law change information
"""
import sqlite3
import os
from datetime import datetime
from typing import List, Dict, Optional
import json


class DatabaseService:
    """Service for managing law changes database operations"""
    
    def __init__(self, db_path: str = None):
        """
        Initialize database service
        
        Args:
            db_path: Path to SQLite database file. If None, uses default location
        """
        if db_path is None:
            # Default to a database in the project root
            project_root = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
            db_path = os.path.join(project_root, 'law_changes.db')
        
        self.db_path = db_path
        self._init_database()
    
    def _init_database(self):
        """Initialize the database and create tables if they don't exist"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                
                # Create law_changes table
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS law_changes (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        date_changed DATE NOT NULL,
                        summary TEXT NOT NULL,
                        state VARCHAR(100) NOT NULL,
                        url TEXT NOT NULL,
                        pdf_filename VARCHAR(255),
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        analysis_data TEXT  -- JSON string with additional analysis data
                    )
                """)
                
                # Create index for better performance
                cursor.execute("""
                    CREATE INDEX IF NOT EXISTS idx_law_changes_state_date 
                    ON law_changes(state, date_changed)
                """)
                
                cursor.execute("""
                    CREATE INDEX IF NOT EXISTS idx_law_changes_date 
                    ON law_changes(date_changed)
                """)
                
                conn.commit()
                print(f"Database initialized at: {self.db_path}")
                
        except sqlite3.Error as e:
            print(f"Error initializing database: {e}")
            raise
    
    def insert_law_change(self, 
                         date_changed: str, 
                         summary: str, 
                         state: str, 
                         url: str,
                         pdf_filename: str = None,
                         analysis_data: Dict = None) -> int:
        """
        Insert a new law change record
        
        Args:
            date_changed: Date the law was changed (YYYY-MM-DD format)
            summary: Summary of the law change
            state: US state where the law was changed
            url: URL associated with the law change
            pdf_filename: Name of the PDF file processed
            analysis_data: Additional analysis data as dictionary
            
        Returns:
            int: ID of the inserted record
        """
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                
                # Convert analysis_data to JSON string if provided
                analysis_json = json.dumps(analysis_data) if analysis_data else None
                
                cursor.execute("""
                    INSERT INTO law_changes 
                    (date_changed, summary, state, url, pdf_filename, analysis_data)
                    VALUES (?, ?, ?, ?, ?, ?)
                """, (date_changed, summary, state, url, pdf_filename, analysis_json))
                
                record_id = cursor.lastrowid
                conn.commit()
                
                print(f"Law change record inserted with ID: {record_id}")
                return record_id
                
        except sqlite3.Error as e:
            print(f"Error inserting law change: {e}")
            raise
    
    def get_law_changes(self, 
                       state: str = None, 
                       start_date: str = None, 
                       end_date: str = None,
                       limit: int = 100) -> List[Dict]:
        """
        Retrieve law changes with optional filtering
        
        Args:
            state: Filter by state name
            start_date: Filter by start date (YYYY-MM-DD)
            end_date: Filter by end date (YYYY-MM-DD)
            limit: Maximum number of records to return
            
        Returns:
            List of law change records as dictionaries
        """
        try:
            with sqlite3.connect(self.db_path) as conn:
                conn.row_factory = sqlite3.Row  # Enable dict-like access
                cursor = conn.cursor()
                
                # Build dynamic query
                query = "SELECT * FROM law_changes WHERE 1=1"
                params = []
                
                if state:
                    query += " AND LOWER(state) = LOWER(?)"
                    params.append(state)
                
                if start_date:
                    query += " AND date_changed >= ?"
                    params.append(start_date)
                
                if end_date:
                    query += " AND date_changed <= ?"
                    params.append(end_date)
                
                query += " ORDER BY date_changed DESC, created_at DESC"
                
                if limit:
                    query += " LIMIT ?"
                    params.append(limit)
                
                cursor.execute(query, params)
                rows = cursor.fetchall()
                
                # Convert to list of dictionaries
                results = []
                for row in rows:
                    record = dict(row)
                    # Parse analysis_data back to dict if present
                    if record['analysis_data']:
                        try:
                            record['analysis_data'] = json.loads(record['analysis_data'])
                        except json.JSONDecodeError:
                            record['analysis_data'] = None
                    results.append(record)
                
                return results
                
        except sqlite3.Error as e:
            print(f"Error retrieving law changes: {e}")
            raise
    
    def get_states_with_changes(self) -> List[str]:
        """
        Get list of all states that have law changes in the database
        
        Returns:
            List of state names
        """
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute("SELECT DISTINCT state FROM law_changes ORDER BY state")
                states = [row[0] for row in cursor.fetchall()]
                return states
                
        except sqlite3.Error as e:
            print(f"Error retrieving states: {e}")
            raise
    
    def get_change_count_by_state(self) -> Dict[str, int]:
        """
        Get count of law changes by state
        
        Returns:
            Dictionary mapping state names to change counts
        """
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    SELECT state, COUNT(*) as count 
                    FROM law_changes 
                    GROUP BY state 
                    ORDER BY count DESC
                """)
                
                return {row[0]: row[1] for row in cursor.fetchall()}
                
        except sqlite3.Error as e:
            print(f"Error retrieving change counts: {e}")
            raise
    
    def delete_law_change(self, record_id: int) -> bool:
        """
        Delete a law change record by ID
        
        Args:
            record_id: ID of the record to delete
            
        Returns:
            bool: True if record was deleted, False if not found
        """
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute("DELETE FROM law_changes WHERE id = ?", (record_id,))
                deleted = cursor.rowcount > 0
                conn.commit()
                
                if deleted:
                    print(f"Law change record {record_id} deleted")
                else:
                    print(f"Law change record {record_id} not found")
                
                return deleted
                
        except sqlite3.Error as e:
            print(f"Error deleting law change: {e}")
            raise
    
    def close(self):
        """Close database connection (for cleanup if needed)"""
        # SQLite connections are managed per operation, no persistent connection to close
        pass


def test_database_service():
    """Test function for database service"""
    db = DatabaseService()
    
    # Test insert
    record_id = db.insert_law_change(
        date_changed="2024-03-15",
        summary="New environmental protection regulations enacted",
        state="California",
        url="https://example.com/ca-env-law",
        pdf_filename="ca_env_law_2024.pdf",
        analysis_data={"confidence": 0.95, "keywords": ["environment", "protection"]}
    )
    
    # Test retrieve
    changes = db.get_law_changes(state="California")
    print(f"Found {len(changes)} law changes for California")
    
    # Test other methods
    states = db.get_states_with_changes()
    print(f"States with changes: {states}")
    
    counts = db.get_change_count_by_state()
    print(f"Change counts by state: {counts}")


if __name__ == "__main__":
    test_database_service()
