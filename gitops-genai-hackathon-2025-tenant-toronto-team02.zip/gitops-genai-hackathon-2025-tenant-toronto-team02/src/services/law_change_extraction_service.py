"""
Law Change Extraction Service
Specialized service for extracting law changes, dates, states, and summaries from PDF documents
"""
import os
import sys
import json
import re
from datetime import datetime
from typing import List, Dict, Any, Optional, Tuple

# Add module paths for document intelligence and rag services
current_dir = os.path.dirname(os.path.abspath(__file__))
doc_intel_path = os.path.join(current_dir, 'document_intelligence')
rag_path = os.path.join(current_dir, 'rag_chatbot')
sys.path.insert(0, doc_intel_path)
sys.path.insert(0, rag_path)

# Import the services - they have the same filename but different classes
sys.path.append(doc_intel_path)
sys.path.append(rag_path)

try:
    from document_intelligence.service import DocumentIntelligenceService
    from rag_chatbot.service import RAGChatbotService
except ImportError:
    # Fallback import method
    import importlib.util
    
    # Load DocumentIntelligenceService
    doc_spec = importlib.util.spec_from_file_location(
        "document_intelligence_service", 
        os.path.join(doc_intel_path, "service.py")
    )
    doc_module = importlib.util.module_from_spec(doc_spec)
    doc_spec.loader.exec_module(doc_module)
    DocumentIntelligenceService = doc_module.DocumentIntelligenceService
    
    # Load RAGChatbotService
    rag_spec = importlib.util.spec_from_file_location(
        "rag_chatbot_service", 
        os.path.join(rag_path, "service.py")
    )
    rag_module = importlib.util.module_from_spec(rag_spec)
    rag_spec.loader.exec_module(rag_module)
    RAGChatbotService = rag_module.RAGChatbotService


class LawChangeExtractionService:
    """
    Service specifically for extracting law changes from legal documents
    """
    
    def __init__(self):
        """Initialize the law change extraction service"""
        print("Initializing Law Change Extraction Service...")
        
        # Initialize sub-services
        self.doc_service = DocumentIntelligenceService(
            env_file_path=os.path.join('src', 'services', 'document_intelligence', '.env')
        )
        self.rag_service = RAGChatbotService(
            env_file_path=os.path.join('src', 'services', 'rag_chatbot', '.env')
        )
        
        print("✓ Document Intelligence Service initialized")
        print("✓ RAG Chatbot Service initialized")
    
    def extract_single_law_change(self, pdf_path: str) -> Optional[Dict]:
        """
        Extract a single comprehensive law change from a PDF document
        
        Args:
            pdf_path: Path to the PDF law document
            
        Returns:
            Dictionary containing law change or None if not found
        """
        try:
            print(f"\n{'='*80}")
            print(f"EXTRACTING LAW CHANGE FROM: {os.path.basename(pdf_path)}")
            print(f"{'='*80}")
            
            # Step 1: Extract text from document
            print("Step 1: Extracting text from PDF...")
            extracted_text = self.doc_service.extract_text_from_pdf(pdf_path)
            
            if not extracted_text:
                print("❌ Failed to extract text from PDF")
                return None
            
            print(f"✓ Extracted {len(extracted_text)} characters of text")
            
            # Generate summary using AI
            print("Step 2: Generating summary using AI")
            summary = self._generate_info(extracted_text)

            law_change = {
                'summary': summary,
                'confidence': 0.8,  # High confidence for single extraction
                'analysis_data': {
                    'extraction_method': 'single_comprehensive',
                    'text_length': len(extracted_text),
                    'pdf_filename': os.path.basename(pdf_path)
                }
            }
            return law_change
            
        except Exception as e:
            print(f"❌ Error extracting law change: {e}")
            return None
    
    def _generate_info(self, text: str) -> str:
        """Generate summary about the legal document using RAG"""
        try:
            # Step 1: Chunk the document text
            chunks = self._create_text_chunks(text, chunk_size=800)
            print(f"Created {len(chunks)} text chunks")
            
            # Step 2: Create embeddings for chunks
            chunk_embeddings = []
            for i, chunk in enumerate(chunks):
                embedding = self.rag_service.create_embedding(chunk)
                chunk_embeddings.append({
                    'chunk_id': i,
                    'text': chunk,
                    'embedding': embedding
                })
            
            # Step 3: Create query embedding for what we're looking for
            query = "What law or regulation is being changed, modified, or enacted? What are the key changes and implications?"
            query_embedding = self.rag_service.create_embedding(query)
            
            # Step 4: Find most relevant chunks using similarity
            relevant_chunks = self._find_most_similar_chunks(
                query_embedding, 
                chunk_embeddings, 
                top_k=3
            )
            
            # Step 5: Combine relevant chunks as context
            context = "\n\n".join([chunk['text'] for chunk in relevant_chunks])
            # print("The context is: ", context[:200] + "..." if len(context) > 200 else context)
            
            # Step 6: Generate response using only relevant context
            prompt = """Based on the following legal document excerpts, provide a comprehensive summary in under 7-8 sentences. Focus on what law or regulation is being changed, modified, or enacted. Be specific about the key changes and their implications.

Context:
{context}

Summary:"""
            
            response = self.rag_service.generate_response(prompt.format(context=context))
            print(f"Generated summary using {len(relevant_chunks)} relevant chunks")
            
            return response
        except Exception as e:
            print(f"Warning: RAG generation failed: {e}")
            return self._generate_basic_summary(text)
    
    def extract_law_changes(self, pdf_path: str) -> List[Dict]:
        """
        Extract law changes (for backwards compatibility)
        Returns a list with a law change
        
        Args:
            pdf_path: Path to the PDF law document
            
        Returns:
            List containing law change dictionary
        """
        single_change = self.extract_single_law_change(pdf_path)
        if single_change:
            return [single_change]
        else:
            return []

    def _create_text_chunks(self, text: str, chunk_size: int = 800, overlap: int = 100) -> List[str]:
        """
        Create overlapping text chunks for better context preservation
        
        Args:
            text: Input text to chunk
            chunk_size: Target size for each chunk (in characters)
            overlap: Number of characters to overlap between chunks
            
        Returns:
            List of text chunks
        """
        chunks = []
        words = text.split()
        
        # Convert to character-based chunking with word boundaries
        current_chunk = ""
        word_idx = 0
        
        while word_idx < len(words):
            # Add words until we reach chunk_size
            while word_idx < len(words) and len(current_chunk) + len(words[word_idx]) + 1 <= chunk_size:
                if current_chunk:
                    current_chunk += " "
                current_chunk += words[word_idx]
                word_idx += 1
            
            if current_chunk.strip():
                chunks.append(current_chunk.strip())
            
            # Calculate overlap for next chunk
            if word_idx < len(words) and overlap > 0:
                # Go back by overlap amount
                overlap_chars = 0
                backtrack_words = []
                temp_idx = word_idx - 1
                
                while temp_idx >= 0 and overlap_chars < overlap:
                    word = words[temp_idx]
                    if overlap_chars + len(word) + 1 <= overlap:
                        backtrack_words.insert(0, word)
                        overlap_chars += len(word) + 1
                        temp_idx -= 1
                    else:
                        break
                
                current_chunk = " ".join(backtrack_words)
                word_idx = temp_idx + 1 + len(backtrack_words)
            else:
                current_chunk = ""
        
        # Filter out very short chunks
        return [chunk for chunk in chunks if len(chunk.strip()) > 50]
    
    def _find_most_similar_chunks(self, query_embedding: List[float], chunk_embeddings: List[Dict], top_k: int = 3) -> List[Dict]:
        """
        Find the most similar chunks to the query using cosine similarity
        
        Args:
            query_embedding: Embedding vector for the query
            chunk_embeddings: List of chunk dictionaries with embeddings
            top_k: Number of top similar chunks to return
            
        Returns:
            List of most similar chunk dictionaries
        """
        import math
        
        def cosine_similarity(vec1: List[float], vec2: List[float]) -> float:
            """Calculate cosine similarity between two vectors"""
            dot_product = sum(a * b for a, b in zip(vec1, vec2))
            magnitude1 = math.sqrt(sum(a * a for a in vec1))
            magnitude2 = math.sqrt(sum(a * a for a in vec2))
            
            if magnitude1 == 0 or magnitude2 == 0:
                return 0
            
            return dot_product / (magnitude1 * magnitude2)
        
        # Calculate similarities
        similarities = []
        for chunk_data in chunk_embeddings:
            similarity = cosine_similarity(query_embedding, chunk_data['embedding'])
            similarities.append({
                'chunk_id': chunk_data['chunk_id'],
                'text': chunk_data['text'],
                'similarity': similarity
            })
        
        # Sort by similarity and return top_k
        similarities.sort(key=lambda x: x['similarity'], reverse=True)
        return similarities[:top_k]

    def _generate_basic_summary(self, text: str) -> str:
        """Generate basic summary without AI assistance"""
        # Look for key legal phrases and sentences
        legal_keywords = [
            'enact', 'amend', 'repeal', 'modify', 'establish', 'create',
            'law', 'bill', 'statute', 'regulation', 'ordinance', 'code'
        ]
        
        sentences = [s.strip() for s in text.split('.') if s.strip()]
        relevant_sentences = []
        
        for sentence in sentences[:50]:  # Check first 50 sentences
            sentence_lower = sentence.lower()
            if any(keyword in sentence_lower for keyword in legal_keywords):
                relevant_sentences.append(sentence)
                if len(relevant_sentences) >= 3:  # Limit to 3 most relevant
                    break
        
        if relevant_sentences:
            summary = '. '.join(relevant_sentences) + '.'
            if len(summary) > 500:
                summary = summary[:500] + "..."
            return summary
        else:
            # Last resort: take first paragraph
            paragraphs = text.split('\n\n')
            first_paragraph = paragraphs[0] if paragraphs else text[:300]
            return first_paragraph[:300] + "..." if len(first_paragraph) > 300 else first_paragraph
