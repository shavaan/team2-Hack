"""
Simplified Azure Document Intelligence Service Module
"""
import requests
import base64
import json
import os
import sys
import time
from dotenv import load_dotenv
from typing import Optional, Dict, Any

# Add shared module to path
sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..', 'shared'))
from auth import get_access_token


class DocumentIntelligenceService:
    """
    Simplified Azure Document Intelligence service for text extraction
    """
    
    def __init__(self, env_file_path: Optional[str] = None):
        """
        Initialize the Document Intelligence service
        
        Args:
            env_file_path: Optional path to environment file
        """
        # Load environment variables
        if env_file_path:
            load_dotenv(env_file_path)
        else:
            load_dotenv()
        
        # OAuth2 configuration
        self.tenant_id = os.getenv("AZURE_TENANT_ID")
        self.client_id = os.getenv("AZURE_CLIENT_ID")
        self.client_secret = os.getenv("AZURE_CLIENT_SECRET")
        self.scope = os.getenv("AZURE_SCOPE")
        
        # Document Intelligence configuration
        self.endpoint = os.getenv("DOCUMENT_INTELLIGENCE_ENDPOINT")
        self.subscription_key = os.getenv("DOCUMENT_INTELLIGENCE_SUBSCRIPTION_KEY")
        
        # Validate environment variables
        # required_vars = [
        #     ("AZURE_TENANT_ID", self.tenant_id),
        #     ("AZURE_CLIENT_ID", self.client_id),
        #     ("AZURE_CLIENT_SECRET", self.client_secret),
        #     ("AZURE_SCOPE", self.scope),
        #     ("DOCUMENT_INTELLIGENCE_ENDPOINT", self.endpoint),
        #     ("DOCUMENT_INTELLIGENCE_SUBSCRIPTION_KEY", self.subscription_key)
        # ]
        
    
    def get_access_token(self) -> Optional[str]:
        """Get OAuth2 access token"""
        return get_access_token(
            self.tenant_id,
            self.client_id,
            self.client_secret,
            self.scope
        )
    
    def extract_text_from_pdf(self, pdf_path: str) -> str:
        """
        Extract text from a PDF file
        
        Args:
            pdf_path: Path to the PDF file
            
        Returns:
            Extracted text content or empty string if failed
        """
        try:
            # Get access token
            bearer_token = self.get_access_token()
            if not bearer_token:
                print("Failed to obtain access token")
                return ""
            
            # Read and encode the PDF file
            with open(pdf_path, "rb") as f:
                base64_encoded_pdf = base64.b64encode(f.read()).decode("utf-8")
            
            # Prepare request
            request_body = {"base64Source": base64_encoded_pdf}
            headers = {
                "Content-Type": "application/json",
                "Authorization": f"Bearer {bearer_token}",
                "Ocp-Apim-Subscription-Key": self.subscription_key
            }
            
            # Start analysis
            response = requests.post(self.endpoint, headers=headers, json=request_body)
            
            if response.status_code == 202:
                # Get operation location
                operation_location = response.headers.get('operation-location')
                if not operation_location:
                    print("No operation location found in response headers")
                    return ""
                
                # Poll for results and extract text
                return self._get_text_from_results(operation_location, headers)
            else:
                print(f"Request failed with status code: {response.status_code}")
                return ""
                
        except Exception as e:
            print(f"Error extracting text from PDF: {str(e)}")
            return ""
    
    def _get_text_from_results(self, operation_location: str, headers: Dict[str, str]) -> str:
        """
        Poll for results and extract text content
        
        Args:
            operation_location: URL to poll for results
            headers: Request headers
            
        Returns:
            Extracted text content
        """
        while True:
            try:
                result_response = requests.get(operation_location, headers=headers)
                
                if result_response.status_code == 200:
                    result_data = result_response.json()
                    
                    if result_data.get('status') == 'succeeded':
                        return self._extract_text_from_result(result_data)
                    elif result_data.get('status') == 'failed':
                        print("Analysis failed")
                        return ""
                    else:
                        print(f"Status: {result_data.get('status', 'Unknown')}")
                        time.sleep(2)  # Wait before polling again
                else:
                    print(f"Error polling results: {result_response.status_code}")
                    return ""
                    
            except Exception as e:
                print(f"Error polling for results: {str(e)}")
                return ""
    
    def _extract_text_from_result(self, result_data: Dict[str, Any]) -> str:
        """
        Extract text from analysis result
        
        Args:
            result_data: Raw analysis results from API
            
        Returns:
            Combined text from all pages
        """
        try:
            analyze_result = result_data.get('analyzeResult', {})
            pages = analyze_result.get('pages', [])
            
            all_text = []
            for page in pages:
                page_text = []
                for line in page.get('lines', []):
                    page_text.append(line.get('content', ''))
                all_text.append('\n'.join(page_text))
            
            return '\n\n'.join(all_text)
            
        except Exception as e:
            print(f"Error extracting text from result: {str(e)}")
            return ""


def main():
    """
    Simple example usage of the Document Intelligence service
    """
    # print("=== Simplified Document Intelligence Service Demo ===\n")
    
    # # Initialize service
    # service = DocumentIntelligenceService()
    
    # # Get PDF file path from environment or use default
    # pdf_file_path = os.getenv("PDF_FILE_PATH")
    # if not pdf_file_path:
    #     print("Error: PDF_FILE_PATH not specified in environment variables")
    #     return
    
    # if not os.path.exists(pdf_file_path):
    #     print(f"Error: File not found at {pdf_file_path}")
    #     return
    
    # # Extract text from PDF
    # print(f"Extracting text from: {pdf_file_path}")
    # text = service.extract_text_from_pdf(pdf_file_path)
    
    # if text:
    #     print(f"\nExtracted text ({len(text)} characters):")
    #     print("-" * 50)
    #     # Show first 500 characters as preview
    #     print(text[:500])
    #     if len(text) > 500:
    #         print("...")
    #         print(f"\n[Full text is {len(text)} characters long]")
    # else:
    #     print("Failed to extract text from PDF")


if __name__ == "__main__":
    main()
