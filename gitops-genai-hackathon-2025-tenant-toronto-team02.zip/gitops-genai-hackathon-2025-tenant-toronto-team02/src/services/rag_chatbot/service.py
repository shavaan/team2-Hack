"""
Simplified RAG (Retrieval-Augmented Generation) Chatbot Service Module
"""
import requests
import json
import os
import sys
from dotenv import load_dotenv
from typing import Optional, List

# Add shared module to path
sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..', 'shared'))
from auth import get_access_token


class RAGChatbotService:
    """
    Simplified RAG Chatbot service using Azure OpenAI
    """
    
    def __init__(self, env_file_path: Optional[str] = None):
        """
        Initialize the RAG Chatbot service
        
        Args:
            env_file_path: Optional path to environment file
        """
        # Load environment variables
        if env_file_path:
            load_dotenv(env_file_path)
        else:
            load_dotenv()
        
        # OAuth2 configuration
        self.tenant_id = os.getenv("AZURE_TENANT_ID")
        self.client_id = os.getenv("AZURE_CLIENT_ID")
        self.client_secret = os.getenv("AZURE_CLIENT_SECRET")
        self.scope = os.getenv("AZURE_SCOPE")
        
        # Azure OpenAI configuration
        self.chat_endpoint = os.getenv("AZURE_OPENAI_CHAT_ENDPOINT")
        self.embedding_endpoint = os.getenv("AZURE_OPENAI_EMBEDDINGS_ENDPOINT")  # Note: EMBEDDINGS with S
        self.subscription_key = os.getenv("AZURE_OPENAI_SUBSCRIPTION_KEY")
        
        # Validate environment variables
        # required_vars = [
        #     ("AZURE_TENANT_ID", self.tenant_id),
        #     ("AZURE_CLIENT_ID", self.client_id),
        #     ("AZURE_CLIENT_SECRET", self.client_secret),
        #     ("AZURE_SCOPE", self.scope),
        #     ("AZURE_OPENAI_CHAT_ENDPOINT", self.chat_endpoint),
        #     ("AZURE_OPENAI_SUBSCRIPTION_KEY", self.subscription_key)
        # ]
    
    def get_access_token(self) -> Optional[str]:
        """Get OAuth2 access token"""
        return get_access_token(
            self.tenant_id,
            self.client_id,
            self.client_secret,
            self.scope
        )
    
    def generate_response(self, prompt: str, context_text: str = "") -> str:
        """
        Generate a response using Azure OpenAI with optional context
        
        Args:
            prompt: The user's prompt/question (can include {context} placeholder)
            context_text: Optional context text for RAG
            
        Returns:
            Generated response text or empty string if failed
        """
        try:
            bearer_token = self.get_access_token()
            if not bearer_token:
                print("Failed to obtain access token for chat")
                return ""
            
            headers = {
                "Content-Type": "application/json",
                "Authorization": f"Bearer {bearer_token}",
                "Ocp-Apim-Subscription-Key": self.subscription_key
            }
            
            # If prompt contains {context} placeholder, format it
            if "{context}" in prompt and context_text:
                formatted_prompt = prompt.format(context=context_text)
            else:
                formatted_prompt = prompt
                # Build the system message with context if provided and no placeholder
                if context_text and "{context}" not in prompt:
                    formatted_prompt = f"Context:\n{context_text[:4000]}\n\nQuestion: {prompt}"
            
            messages = [
                {
                    "role": "system",
                    "content": "You are a helpful assistant specialized in legal document analysis."
                },
                {
                    "role": "user",
                    "content": formatted_prompt
                }
            ]
            
            request_body = {
                "model": "gpt-35-turbo",
                "messages": messages,
                "temperature": 0.3,  # Lower temperature for more consistent legal analysis
                "max_tokens": 1500,
                "top_p": 1,
                "frequency_penalty": 0,
                "presence_penalty": 0
            }
            
            response = requests.post(self.chat_endpoint, headers=headers, json=request_body)
            
            if response.status_code == 200:
                result = response.json()
                return result['choices'][0]['message']['content'].strip()
            else:
                print(f"Failed to get chat response. Status code: {response.status_code}")
                print(f"Response: {response.text}")
                return ""
                
        except Exception as e:
            print(f"Error generating response: {str(e)}")
            return ""
    
    def create_embedding(self, text: str) -> List[float]:
        """
        Create an embedding vector for the given text using Azure OpenAI
        
        Args:
            text: Text to create embedding for
            
        Returns:
            List of floats representing the embedding vector
        """
        try:
            bearer_token = self.get_access_token()
            if not bearer_token:
                print("Failed to obtain access token for embeddings")
                return []
            
            headers = {
                "Content-Type": "application/json",
                "Authorization": f"Bearer {bearer_token}",
                "Ocp-Apim-Subscription-Key": self.subscription_key
            }
            
            request_body = {
                "model": "text-embedding-3-large",
                "input": text[:8000]  # Limit text length for embeddings
            }
            
            response = requests.post(self.embedding_endpoint, headers=headers, json=request_body)

            if response.status_code == 200:
                result = response.json()
                # print("Got embeddings: ", result['data'][0]['embedding'])
                return result['data'][0]['embedding']
            else:
                print(f"Failed to get embedding. Status code: {response.status_code}")
                print(f"Response: {response.text}")
                return []
                
        except Exception as e:
            print(f"Error creating embedding: {str(e)}")
            return []


def main():
    """
    Simple example usage of the RAG Chatbot service
    """
    print("=== Simplified RAG Chatbot Service Demo ===\n")
    
    # Initialize service
    service = RAGChatbotService()
    
    # Example usage without context
    print("Example 1: Simple question without context")
    response1 = service.generate_response("What is artificial intelligence?")
    print(f"Response: {response1}\n")
    
    # Example usage with context
    print("Example 2: Question with context")
    context = """
    House Bill 1155 was signed into law on March 15, 2025, in the state of California.
    This bill requires all public schools to implement new cybersecurity protocols
    for their online learning platforms by September 1, 2025.
    """
    
    prompt = "Extract the date, state, and summary of this law change as a JSON object."
    response2 = service.generate_response(prompt, context)
    print(f"Context: {context[:100]}...")
    print(f"Prompt: {prompt}")
    print(f"Response: {response2}")


if __name__ == "__main__":
    main()
