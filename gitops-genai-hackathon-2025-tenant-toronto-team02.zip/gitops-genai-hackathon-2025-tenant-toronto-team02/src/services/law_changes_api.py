"""
Law Changes API Service

This service provides an API for processing PDF files to extract law changes
and store them in a database. It coordinates between the extraction service
and database service to provide a complete solution.
"""

import os
import re
import sys
from typing import Dict, List, Optional
from datetime import datetime

# Add the parent directory to sys.path to access utils
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
sys.path.insert(0, parent_dir)

from services.database_service import DatabaseService
from services.law_change_extraction_service import LawChangeExtractionService
from utils.pdf_manager import PDFManager


class LawChangesAPI:
    """API service for processing law changes from PDFs"""
    
    def __init__(self, db_path: str = None):
        """
        Initialize the API service
        
        Args:
            db_path: Path to database file (optional)
        """
        self.db_service = DatabaseService(db_path)
        self.extraction_service = LawChangeExtractionService()
        self.pdf_manager = PDFManager()
    
    def get_pdf_summary(self, pdf_filename: str) -> str:
        """
        Process a PDF file to extract law changes and return summary
        
        Args:
            pdf_filename: Name of the PDF file (will be looked up in pdfs directory)
            
        Returns:
            String summary of PDF
        """
        try:
            # Construct full path to PDF in pdfs directory
            current_dir = os.path.dirname(os.path.abspath(__file__))
            project_root = os.path.dirname(os.path.dirname(current_dir))
            pdf_path = os.path.join(project_root, "pdfs", pdf_filename)
            
            # Validate inputs
            if not os.path.exists(pdf_path):
                return {
                    'status': 'error',
                    'message': f'PDF file not found: {pdf_path} (looking for {pdf_filename} in pdfs directory)'
                }
            
            print(f"Processing PDF: {pdf_path}")
            # Extract summary from PDF
            summary = self._extract_law_change_from_pdf(pdf_path)
            
            if not summary:
                return ""

            return summary
            
        except Exception as e:
            return {
                'status': 'error',
                'message': f'Error processing PDF: {str(e)}'
            }
    
    def _extract_law_change_from_pdf(self, pdf_path: str) -> str:
        """
        Extract law change summary from PDF using the law change extraction service
        
        Args:
            pdf_path: Path to PDF file
            
        Returns:
            Summary string of the law change or empty string if no change found
        """
        try:
            # Use the specialized extraction service for law change
            law_change = self.extraction_service.extract_single_law_change(pdf_path)

            if law_change and 'summary' in law_change:
                return law_change['summary']
            else:
                return ""
            
        except Exception as e:
            print(f"Error extracting law change: {e}")
            return ""

    def _is_valid_url(self, url: str) -> bool:
        """Validate URL format"""
        url_pattern = re.compile(
            r'^https?://'  # http:// or https://
            r'(?:(?:[A-Z0-9](?:[A-Z0-9-]{0,61}[A-Z0-9])?\.)+[A-Z]{2,6}\.?|'  # domain...
            r'localhost|'  # localhost...
            r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})'  # ...or ip
            r'(?::\d+)?'  # optional port
            r'(?:/?|[/?]\S+)$', re.IGNORECASE)
        return url_pattern.match(url) is not None
    

def main():
    l = LawChangesAPI()
    print("processing pdf")
    # Use a real PDF file from the pdfs directory
    result = l.get_pdf_summary("example.pdf")
    print("Got Result: ", result)


if __name__ == "__main__":
    main()