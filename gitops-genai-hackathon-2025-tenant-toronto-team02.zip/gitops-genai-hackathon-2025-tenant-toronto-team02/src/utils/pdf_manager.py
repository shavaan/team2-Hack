"""
PDF Management Helper Script
Utilities for managing PDF documents in the law analysis system
"""
import os
import shutil
from typing import List


class PDFManager:
    """Helper class for managing PDF documents"""
    
    def __init__(self, base_dir: str = "C:/dev/hackathon"):
        self.base_dir = base_dir
        self.pdfs_dir = os.path.join(base_dir, "pdfs")
        
        # Ensure pdfs directory exists
        os.makedirs(self.pdfs_dir, exist_ok=True)
    
    def list_pdfs(self) -> List[str]:
        """List all PDF files in the pdfs directory"""
        try:
            files = os.listdir(self.pdfs_dir)
            pdfs = [f for f in files if f.lower().endswith('.pdf')]
            return sorted(pdfs)
        except FileNotFoundError:
            return []
    
    def add_pdf(self, source_path: str, destination_name: str = None) -> bool:
        """
        Copy a PDF file to the pdfs directory
        
        Args:
            source_path: Path to the source PDF file
            destination_name: Optional new name for the file
            
        Returns:
            True if successful, False otherwise
        """
        if not os.path.exists(source_path):
            print(f"Error: Source file not found: {source_path}")
            return False
        
        if not source_path.lower().endswith('.pdf'):
            print(f"Error: File is not a PDF: {source_path}")
            return False
        
        # Determine destination filename
        if destination_name:
            if not destination_name.lower().endswith('.pdf'):
                destination_name += '.pdf'
        else:
            destination_name = os.path.basename(source_path)
        
        destination_path = os.path.join(self.pdfs_dir, destination_name)
        
        try:
            shutil.copy2(source_path, destination_path)
            print(f"✓ Added PDF: {destination_name}")
            return True
        except Exception as e:
            print(f"Error copying file: {e}")
            return False
    
    def remove_pdf(self, filename: str) -> bool:
        """
        Remove a PDF file from the pdfs directory
        
        Args:
            filename: Name of the PDF file to remove
            
        Returns:
            True if successful, False otherwise
        """
        file_path = os.path.join(self.pdfs_dir, filename)
        
        if not os.path.exists(file_path):
            print(f"Error: File not found: {filename}")
            return False
        
        try:
            os.remove(file_path)
            print(f"✓ Removed PDF: {filename}")
            return True
        except Exception as e:
            print(f"Error removing file: {e}")
            return False
    
    def get_pdf_paths(self) -> List[str]:
        """Get full paths to all PDF files"""
        pdfs = self.list_pdfs()
        return [os.path.join(self.pdfs_dir, pdf) for pdf in pdfs]
    
    def generate_demo_paths(self) -> str:
        """Generate Python code for pdf_paths list in demo script"""
        pdfs = self.list_pdfs()
        
        if not pdfs:
            return """pdf_paths = [
    # Add your PDF files to the pdfs/ directory
    # os.path.join(pdfs_dir, "your_document.pdf"),
]"""
        
        lines = ["pdf_paths = ["]
        for pdf in pdfs:
            lines.append(f'    os.path.join(pdfs_dir, "{pdf}"),')
        lines.append("]")
        
        return "\n".join(lines)
    
    def print_status(self):
        """Print current status of PDF directory"""
        pdfs = self.list_pdfs()
        
        print("="*60)
        print("PDF DIRECTORY STATUS")
        print("="*60)
        print(f"Directory: {self.pdfs_dir}")
        print(f"PDF files found: {len(pdfs)}")
        
        if pdfs:
            print("\nAvailable PDFs:")
            for i, pdf in enumerate(pdfs, 1):
                file_path = os.path.join(self.pdfs_dir, pdf)
                file_size = os.path.getsize(file_path) / 1024 / 1024  # MB
                print(f"  {i}. {pdf} ({file_size:.2f} MB)")
        else:
            print("\nNo PDF files found.")
            print("\nTo add PDFs:")
            print("  1. Copy PDF files to the pdfs/ directory")
            print("  2. Or use: python pdf_manager.py add <source_file>")
        
        print("\nGenerated paths for demo script:")
        print(self.generate_demo_paths())
        print("="*60)
    
    def scan_for_pdfs(self, scan_dir: str = None) -> List[str]:
        """
        Scan a directory for PDF files that could be added
        
        Args:
            scan_dir: Directory to scan (defaults to parent directory)
            
        Returns:
            List of PDF files found
        """
        if scan_dir is None:
            scan_dir = os.path.dirname(self.base_dir)
        
        found_pdfs = []
        
        if os.path.exists(scan_dir):
            for file in os.listdir(scan_dir):
                if file.lower().endswith('.pdf'):
                    full_path = os.path.join(scan_dir, file)
                    found_pdfs.append(full_path)
        
        return found_pdfs
    
    def auto_add_pdfs(self, scan_dir: str = None) -> int:
        """
        Automatically add any PDF files found in a directory
        
        Args:
            scan_dir: Directory to scan (defaults to parent directory)
            
        Returns:
            Number of PDFs added
        """
        found_pdfs = self.scan_for_pdfs(scan_dir)
        added_count = 0
        
        for pdf_path in found_pdfs:
            filename = os.path.basename(pdf_path)
            destination_path = os.path.join(self.pdfs_dir, filename)
            
            # Don't add if already exists
            if not os.path.exists(destination_path):
                if self.add_pdf(pdf_path):
                    added_count += 1
            else:
                print(f"Skipped (already exists): {filename}")
        
        return added_count


def main():
    """Command-line interface for PDF management"""
    import sys
    
    manager = PDFManager()
    
    if len(sys.argv) < 2:
        manager.print_status()
        return
    
    command = sys.argv[1].lower()
    
    if command == "list":
        pdfs = manager.list_pdfs()
        if pdfs:
            print("PDFs in directory:")
            for pdf in pdfs:
                print(f"  • {pdf}")
        else:
            print("No PDFs found.")
    
    elif command == "add":
        if len(sys.argv) < 3:
            print("Usage: python pdf_manager.py add <source_file> [destination_name]")
            return
        
        source_path = sys.argv[2]
        destination_name = sys.argv[3] if len(sys.argv) > 3 else None
        
        success = manager.add_pdf(source_path, destination_name)
        if success:
            manager.print_status()
    
    elif command == "remove":
        if len(sys.argv) < 3:
            print("Usage: python pdf_manager.py remove <filename>")
            return
        
        filename = sys.argv[2]
        success = manager.remove_pdf(filename)
        if success:
            manager.print_status()
    
    elif command == "paths":
        print("Full paths to all PDFs:")
        for path in manager.get_pdf_paths():
            print(f"  {path}")
    
    elif command == "demo":
        print("Copy this code to multi_pdf_demo.py:")
        print()
        print(manager.generate_demo_paths())
    
    elif command == "status":
        manager.print_status()
    
    elif command == "scan":
        scan_dir = sys.argv[2] if len(sys.argv) > 2 else None
        found_pdfs = manager.scan_for_pdfs(scan_dir)
        
        if found_pdfs:
            print(f"Found {len(found_pdfs)} PDF files:")
            for pdf in found_pdfs:
                print(f"  • {pdf}")
            print(f"\nTo add them, run: python pdf_manager.py auto-add")
        else:
            scan_location = scan_dir or os.path.dirname(manager.base_dir)
            print(f"No PDF files found in: {scan_location}")
    
    elif command == "auto-add":
        scan_dir = sys.argv[2] if len(sys.argv) > 2 else None
        added_count = manager.auto_add_pdfs(scan_dir)
        
        if added_count > 0:
            print(f"\n✓ Added {added_count} PDF files")
            manager.print_status()
        else:
            print("No new PDF files to add")
    
    else:
        print("Available commands:")
        print("  list        - List all PDFs in the pdfs directory")
        print("  add         - Add a PDF file")
        print("  remove      - Remove a PDF file")
        print("  paths       - Show full paths to all PDFs")
        print("  demo        - Generate demo code for multi_pdf_demo.py")
        print("  status      - Show directory status")
        print("  scan        - Scan for PDF files that can be added")
        print("  auto-add    - Automatically add found PDF files")
        print()
        print("Examples:")
        print("  python pdf_manager.py add ../my_law.pdf")
        print("  python pdf_manager.py add /path/to/document.pdf custom_name.pdf")
        print("  python pdf_manager.py scan ../")
        print("  python pdf_manager.py auto-add")


if __name__ == "__main__":
    main()
